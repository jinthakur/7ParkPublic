﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SharedProject1
{
    internal class Class1
    {
    }
}
