using System;
using System.Runtime.InteropServices;

namespace BCBSAZ.BMS.ICM.Helper
{
	[System.Runtime.InteropServices.Guid("C959FF3B-02BB-4d6d-9145-4F87EC56A3FF")]
	public enum HashAlgorithmType
	{
		MD5 = 1,
		SHA1,
		SHA256,
		SHA384,
		SHA512
	}
}
