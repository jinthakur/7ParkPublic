using Microsoft.XLANGs.BaseTypes;
using System;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using System.IO;
using System.Text.RegularExpressions;
using System.Xml;

namespace BCBSAZ.BMS.ICM.Helper
{
	[System.Serializable]
	public class Utilities
	{
		private const string AppName = "BCBSAZ.BMS.ICM";

		private static System.DateTime _securityKeyLastAccessDate = System.DateTime.Now;

		private static string _securityKey = string.Empty;

		public static string GetSecurityKey()
		{
			System.TimeSpan timeSpan = System.DateTime.Now.Subtract(Utilities._securityKeyLastAccessDate);
			int num = System.Convert.ToInt32(SSOClientHelper.Read("BCBSAZ.BMS.ICM", "CacheInterval"));
			if (Utilities._securityKey == string.Empty || timeSpan.TotalMinutes >= (double)num)
			{
				Utilities._securityKey = string.Empty;
			}
			else
			{
				Debug.Write("GetSecurityKey: ", "Existing Security Key returned");
			}
			Utilities._securityKeyLastAccessDate = System.DateTime.Now;
			return Utilities._securityKey;
		}

		public string GetPdfString(XLANGMessage doc)
		{
			string result = string.Empty;
			System.IO.Stream stream = (System.IO.Stream)doc[0].RetrieveAs(typeof(System.IO.Stream));
			using (stream)
			{
				System.IO.MemoryStream memoryStream = new System.IO.MemoryStream();
				byte[] array = new byte[65536];
				int count;
				while ((count = stream.Read(array, 0, array.Length)) > 0)
				{
					memoryStream.Write(array, 0, count);
				}
				result = System.Convert.ToBase64String(memoryStream.ToArray());
			}
			return result;
		}

		public byte[] GetBinary(XLANGMessage doc)
		{
			string text = string.Empty;
			System.IO.Stream stream = (System.IO.Stream)doc[0].RetrieveAs(typeof(System.IO.Stream));
			byte[] result;
			using (stream)
			{
				System.IO.MemoryStream memoryStream = new System.IO.MemoryStream();
				byte[] array = new byte[65536];
				int count;
				while ((count = stream.Read(array, 0, array.Length)) > 0)
				{
					memoryStream.Write(array, 0, count);
				}
				text = System.Convert.ToBase64String(memoryStream.ToArray());
				result = memoryStream.ToArray();
			}
			return result;
		}

		public static void CreateMessageFromString(XLANGMessage message, string base64data)
		{
			byte[] b = System.Convert.FromBase64String(base64data);
			message[0].LoadFrom(new CustomStreamFactory(b));
		}

		public static void CreateMessageFromBytes(XLANGMessage message, byte[] base64data)
		{
			message[0].LoadFrom(new CustomStreamFactory(base64data));
		}

		public static XmlDocument GetMessageFromXmlString(string XmlString, string Namespace)
		{
			XmlDocument xmlDocument = new XmlDocument();
			XmlString = Utilities.DecodeXmlString(XmlString);
			XmlString = Utilities.InsertNamespaceString(XmlString, Namespace);
			xmlDocument.LoadXml(XmlString);
			return xmlDocument;
		}

		public static XmlDocument GetMessageFromXmlString(string XmlString)
		{
			XmlDocument xmlDocument = new XmlDocument();
			XmlString = Utilities.DecodeXmlString(XmlString);
			xmlDocument.LoadXml(XmlString);
			return xmlDocument;
		}

		private static string DecodeXmlString(string XmlString)
		{
			XmlString = XmlString.Replace("&lt;", "<");
			XmlString = XmlString.Replace("&gt;", ">");
			XmlString = XmlString.Replace("&quot;", "\"");
			XmlString = XmlString.Replace("&apos;", "'");
			XmlString = XmlString.Replace("&amp;", "&");
			return XmlString;
		}

		private static string InsertNamespaceString(string XmlString, string Namespace)
		{
			return Utilities.InsertNamespaceString(XmlString, Namespace, string.Empty);
		}

		private static string InsertNamespaceString(string XmlString, string Namespace, string NSPrefix)
		{
			int startIndex = XmlString.IndexOf(">");
			string value = string.Empty;
			if (NSPrefix.Trim() == string.Empty)
			{
				value = string.Format(" xmlns=\"{0}\"", Namespace);
			}
			else
			{
				value = string.Format(" xmlns:{0}=\"{1}\"", NSPrefix, Namespace);
			}
			XmlString = XmlString.Insert(startIndex, value);
			return XmlString;
		}

		public static void CreateFolder(string folderLocation, string folderName)
		{
			string path = folderLocation + "\\" + folderName;
			if (!System.IO.Directory.Exists(path))
			{
				try
				{
					System.IO.Directory.CreateDirectory(path);
				}
				catch (System.Exception innerException)
				{
					throw new System.Exception("folder location doesnot exist check the exception for more details", innerException);
				}
			}
		}

		public static void SaveDocumentToUploadFolder(string docString, string folderlocation, string fileName, string extension)
		{
			byte[] bytes = System.Convert.FromBase64String(docString);
			System.IO.File.WriteAllBytes(folderlocation + "\\" + fileName + extension, bytes);
		}

		public string ConstructFileName(string BaseName, string ContentFormat, int PageNumber)
		{
			string empty = string.Empty;
			string str = "." + ContentFormat;
			BaseName = BaseName + "-" + PageNumber.ToString("000");
			return BaseName.Trim() + str;
		}

		public static void RemoveFolder(string folderLocation, string folderName)
		{
			string path = folderLocation + "\\" + folderName;
			bool flag = System.IO.Directory.Exists(path);
			if (flag)
			{
				try
				{
					System.IO.Directory.Delete(path, true);
				}
				catch (System.Exception innerException)
				{
					throw new System.Exception("folder location doesnot exist check the exception for more details", innerException);
				}
			}
		}

		public static void UpdateWFQueueStatus(string queueId, string errorMsg)
		{
			string connectionString = SSOClientHelper.Read("BCBSAZ.BMS.ICM", "TICustomConnection");
			try
			{
				using (SqlConnection sqlConnection = new SqlConnection(connectionString))
				{
					using (SqlCommand sqlCommand = new SqlCommand("usp_UpdateWorkFlowQueueStatus", sqlConnection))
					{
						sqlCommand.CommandType = CommandType.StoredProcedure;
						sqlCommand.Parameters.AddWithValue("@QueueId", queueId);
						sqlCommand.Parameters.AddWithValue("@Error", errorMsg);
						sqlCommand.Connection.Open();
						sqlCommand.ExecuteNonQuery();
						sqlCommand.Connection.Close();
					}
				}
			}
			catch (System.Exception)
			{
				throw;
			}
		}

		public static void UpdateWFOBUserQueueStatus(string queueId, string status, string errorMsg)
		{
			string connectionString = SSOClientHelper.Read("BCBSAZ.BMS.ICM", "TICustomConnection");
			try
			{
				using (SqlConnection sqlConnection = new SqlConnection(connectionString))
				{
					using (SqlCommand sqlCommand = new SqlCommand("usp_UpdateWFOnboardingUserQueueStatus", sqlConnection))
					{
						sqlCommand.CommandType = CommandType.StoredProcedure;
						sqlCommand.Parameters.AddWithValue("@QueueId", queueId);
						sqlCommand.Parameters.AddWithValue("@Status", status);
						sqlCommand.Parameters.AddWithValue("@Error", errorMsg);
						sqlCommand.Connection.Open();
						sqlCommand.ExecuteNonQuery();
						sqlCommand.Connection.Close();
					}
				}
			}
			catch (System.Exception)
			{
				throw;
			}
		}

		public static XmlDocument SetEntityId(XmlDocument document, string Key, string KeyValue)
		{
			string xml = string.Concat(new string[]
			{
				"<KeyValuePair><Key>",
				Key,
				"</Key><Value>",
				KeyValue,
				"</Value></KeyValuePair>"
			});
			XmlDocument xmlDocument = new XmlDocument();
			xmlDocument.LoadXml(xml);
			document.DocumentElement.AppendChild(document.ImportNode(xmlDocument.DocumentElement, true));
			return document;
		}

		public static XmlDocument GetAddressXmlString(XmlDocument SourceXml, XmlDocument DestinationXml)
		{
			XmlNodeList xmlNodeList = SourceXml.SelectNodes("//*[local-name()='KeyValuePairOfstringanyType' and namespace-uri()='http://schemas.microsoft.com/xrm/2011/Contracts']/*[local-name()='key' and namespace-uri()='http://schemas.datacontract.org/2004/07/System.Collections.Generic']");
			XmlNodeList xmlNodeList2 = SourceXml.SelectNodes("//*[local-name()='KeyValuePairOfstringanyType' and namespace-uri()='http://schemas.microsoft.com/xrm/2011/Contracts']");
			XmlDocument xmlDocument = new XmlDocument();
			string text = "";
			foreach (XmlNode xmlNode in xmlNodeList2)
			{
				string innerText = xmlNode.ChildNodes[0].InnerText;
				string innerText2 = xmlNode.ChildNodes[1].InnerText;
				text = string.Concat(new string[]
				{
					text,
					"<",
					innerText,
					">",
					innerText2,
					"</",
					innerText,
					">"
				});
			}
			xmlDocument.LoadXml("<Address>" + text + "</Address>");
			XmlNode newChild = DestinationXml.CreateNode(XmlNodeType.Element, "AddressDetails", null);
			XmlNode xmlNode2 = DestinationXml.SelectSingleNode("//AddressDetails");
			if (xmlNode2 != null)
			{
				foreach (XmlNode node in xmlDocument.ChildNodes)
				{
					DestinationXml.SelectSingleNode("//AddressDetails").AppendChild(DestinationXml.ImportNode(node, true));
				}
			}
			else
			{
				DestinationXml.DocumentElement.AppendChild(newChild);
				foreach (XmlNode node in xmlDocument.ChildNodes)
				{
					DestinationXml.SelectSingleNode("//AddressDetails").AppendChild(DestinationXml.ImportNode(node, true));
				}
			}
			return DestinationXml;
		}

		public static XmlDocument GetCRMBrokerAgentFirmId(XmlDocument RetrieveResponse, XmlDocument OfficeUser)
		{
			XmlNodeList xmlNodeList = RetrieveResponse.SelectNodes("//*[local-name()='KeyValuePairOfstringanyType' and namespace-uri()='http://schemas.microsoft.com/xrm/2011/Contracts']");
			string keyValue = "";
			string keyValue2 = "";
			string keyValue3 = "";
			string keyValue4 = "";
			XmlDocument result = null;
			foreach (XmlNode xmlNode in xmlNodeList)
			{
				string innerText = xmlNode.ChildNodes[0].InnerText;
				if (innerText == "ap.bcbs_brokerid")
				{
					keyValue = xmlNode.ChildNodes[1].ChildNodes[2].InnerText;
				}
				else if (innerText == "ap.bcbs_npn")
				{
					keyValue4 = xmlNode.ChildNodes[1].ChildNodes[2].InnerText;
				}
				else if (innerText == "bcbs_agentid")
				{
					keyValue2 = xmlNode.ChildNodes[1].InnerText;
				}
				else if (innerText == "aq.bcbs_firmid")
				{
					keyValue3 = xmlNode.ChildNodes[1].ChildNodes[2].InnerText;
				}
			}
			if (xmlNodeList != null)
			{
				XmlDocument document = Utilities.SetEntityId(OfficeUser, "bcbs_broker", keyValue);
				document = Utilities.SetEntityId(document, "bokernpn", keyValue4);
				XmlDocument document2 = Utilities.SetEntityId(document, "bcbs_agent", keyValue2);
				result = Utilities.SetEntityId(document2, "bcbs_firm", keyValue3);
			}
			return result;
		}

		public static XmlDocument GetCRMBrokerFirmId(XmlDocument RetrieveResponse, XmlDocument OfficeUser)
		{
			XmlNodeList xmlNodeList = RetrieveResponse.SelectNodes("//*[local-name()='KeyValuePairOfstringanyType' and namespace-uri()='http://schemas.microsoft.com/xrm/2011/Contracts']");
			string keyValue = "";
			XmlDocument result = null;
			foreach (XmlNode xmlNode in xmlNodeList)
			{
				string innerText = xmlNode.ChildNodes[0].InnerText;
				if (innerText == "bcbs_firmid")
				{
					keyValue = xmlNode.ChildNodes[1].InnerText;
				}
			}
			if (xmlNodeList != null)
			{
				result = Utilities.SetEntityId(OfficeUser, "bcbs_firm", keyValue);
			}
			return result;
		}

		public bool CheckIfStreetAddress(string address)
		{
			address = address.ToUpper();
			bool flag = false;
			bool result = false;
			string pattern = string.Format("^(({0}))", "ALLEY|ALLEE|ALY|ALLEY|ALLY|ALY|ANEX|ANEX|ANX|ANNEX|ANNX|ANX|ARCADE|ARC|ARC|ARCADE|AVENUE|AV|AVE|AVE|AVEN|AVENU|AVENUE|AVN|AVNUE|BAYOU|BAYOO|BYU|BAYOU|BEACH|BCH|BCH|BEACH|BEND|BEND|BND|BND|BLUFF|BLF|BLF|BLUF|BLUFF|BLUFFS|BLUFFS|BLFS|BOTTOM|BOT|BTM|BTM|BOTTM|BOTTOM|BOULEVARD|BLVD|BLVD|BOUL|BOULEVARD|BOULV|BRANCH|BR|BR|BRNCH|BRANCH|BRIDGE|BRDGE|BRG|BRG|BRIDGE|BROOK|BRK|BRK|BROOK|BROOKS|BROOKS|BRKS|BURG|BURG|BG|BURGS|BURGS|BGS|BYPASS|BYP|BYP|BYPA|BYPAS|BYPASS|BYPS|CAMP|CAMP|CP|CP|CMP|CANYON|CANYN|CYN|CANYON|CNYN|CAPE|CAPE|CPE|CPE|CAUSEWAY|CAUSEWAY|CSWY|CAUSWA|CSWY|CENTER|CEN|CTR|CENT|CENTER|CENTR|CENTRE|CNTER|CNTR|CTR|CENTERS|CENTERS|CTRS|CIRCLE|CIR|CIR|CIRC|CIRCL|CIRCLE|CRCL|CRCLE|CIRCLES|CIRCLES|CIRS|CLIFF|CLF|CLF|CLIFF|CLIFFS|CLFS|CLFS|CLIFFS|CLUB|CLB|CLB|CLUB|COMMON|COMMON|CMN|COMMONS|COMMONS|CMNS|CORNER|COR|COR|CORNER|CORNERS|CORNERS|CORS|CORS|COURSE|COURSE|CRSE|CRSE|COURT|COURT|CT|CT|COURTS|COURTS|CTS|CTS|COVE|COVE|CV|CV|COVES|COVES|CVS|CREEK|CREEK|CRK|CRK|CRESCENT|CRESCENT|CRES|CRES|CRSENT|CRSNT|CREST|CREST|CRST|CROSSING|CROSSING|XING|CRSSNG|XING|CROSSROAD|CROSSROAD|XRD|CROSSROADS|CROSSROADS|XRDS|CURVE|CURVE|CURV|DALE|DALE|DL|DL|DAM|DAM|DM|DM|DIVIDE|DIV|DV|DIVIDE|DV|DVD|DRIVE|DR|DR|DRIV|DRIVE|DRV|DRIVES|DRIVES|DRS|ESTATE|EST|EST|ESTATE|ESTATES|ESTATES|ESTS|ESTS|EXPRESSWAY|EXP|EXPY|EXPR|EXPRESS|EXPRESSWAY|EXPW|EXPY|EXTENSION|EXT|EXT|EXTENSION|EXTN|EXTNSN|EXTENSIONS|EXTS|EXTS|FALL|FALL|FALL|FALLS|FALLS|FLS|FLS|FERRY|FERRY|FRY|FRRY|FRY|FIELD|FIELD|FLD|FLD|FIELDS|FIELDS|FLDS|FLDS|FLAT|FLAT|FLT|FLT|FLATS|FLATS|FLTS|FLTS|FORD|FORD|FRD|FRD|FORDS|FORDS|FRDS|FOREST|FOREST|FRST|FORESTS|FRST|FORGE|FORG|FRG|FORGE|FRG|FORGES|FORGES|FRGS|FORK|FORK|FRK|FRK|FORKS|FORKS|FRKS|FRKS|FORT|FORT|FT|FRT|FT|FREEWAY|FREEWAY|FWY|FREEWY|FRWAY|FRWY|FWY|GARDEN|GARDEN|GDN|GARDN|GRDEN|GRDN|GARDENS|GARDENS|GDNS|GDNS|GRDNS|GATEWAY|GATEWAY|GTWY|GATEWY|GATWAY|GTWAY|GTWY|GLEN|GLEN|GLN|GLN|GLENS|GLENS|GLNS|GREEN|GREEN|GRN|GRN|GREENS|GREENS|GRNS|GROVE|GROV|GRV|GROVE|GRV|GROVES|GROVES|GRVS|HARBOR|HARB|HBR|HARBOR|HARBR|HBR|HRBOR|HARBORS|HARBORS|HBRS|HAVEN|HAVEN|HVN|HVN|HEIGHTS|HT|HTS|HTS|HIGHWAY|HIGHWAY|HWY|HIGHWY|HIWAY|HIWY|HWAY|HWY|HILL|HILL|HL|HL|HILLS|HILLS|HLS|HLS|HOLLOW|HLLW|HOLW|HOLLOW|HOLLOWS|HOLW|HOLWS|INLET|INLT|INLT|ISLAND|IS|IS|ISLAND|ISLND|ISLANDS|ISLANDS|ISS|ISLNDS|ISS|ISLE|ISLE|ISLE|ISLES|JUNCTION|JCT|JCT|JCTION|JCTN|JUNCTION|JUNCTN|JUNCTON|JUNCTIONS|JCTNS|JCTS|JCTS|JUNCTIONS|KEY|KEY|KY|KY|KEYS|KEYS|KYS|KYS|KNOLL|KNL|KNL|KNOL|KNOLL|KNOLLS|KNLS|KNLS|KNOLLS|LAKE|LK|LK|LAKE|LAKES|LKS|LKS|LAKES|LAND|LAND|LAND|LANDING|LANDING|LNDG|LNDG|LNDNG|LANE|LANE|LN|LN|LIGHT|LGT|LGT|LIGHT|LIGHTS|LIGHTS|LGTS|LOAF|LF|LF|LOAF|LOCK|LCK|LCK|LOCK|LOCKS|LCKS|LCKS|LOCKS|LODGE|LDG|LDG|LDGE|LODG|LODGE|LOOP|LOOP|LOOP|LOOPS|MALL|MALL|MALL|MANOR|MNR|MNR|MANOR|MANORS|MANORS|MNRS|MNRS|MEADOW|MEADOW|MDW|MEADOWS|MDW|MDWS|MDWS|MEADOWS|MEDOWS|MEWS|MEWS|MEWS|MILL|MILL|ML|MILLS|MILLS|MLS|MISSION|MISSN|MSN|MSSN|MOTORWAY|MOTORWAY|MTWY|MOUNT|MNT|MT|MT|MOUNT|MOUNTAIN|MNTAIN|MTN|MNTN|MOUNTAIN|MOUNTIN|MTIN|MTN|MOUNTAINS|MNTNS|MTNS|MOUNTAINS|NECK|NCK|NCK|NECK|ORCHARD|ORCH|ORCH|ORCHARD|ORCHRD|OVAL|OVAL|OVAL|OVL|OVERPASS|OVERPASS|OPAS|PARK|PARK|PARK|PRK|PARKS|PARKS|PARK|PARKWAY|PARKWAY|PKWY|PARKWY|PKWAY|PKWY|PKY|PARKWAYS|PARKWAYS|PKWY|PKWYS|PASS|PASS|PASS|PASSAGE|PASSAGE|PSGE|PATH|PATH|PATH|PATHS|PIKE|PIKE|PIKE|PIKES|PINE|PINE|PNE|PINES|PINES|PNES|PNES|PLACE|PL|PL|PLAIN|PLAIN|PLN|PLN|PLAINS|PLAINS|PLNS|PLNS|PLAZA|PLAZA|PLZ|PLZ|PLZA|POINT|POINT|PT|PT|POINTS|POINTS|PTS|PTS|PORT|PORT|PRT|PRT|PORTS|PORTS|PRTS|PRTS|PRAIRIE|PR|PR|PRAIRIE|PRR|RADIAL|RAD|RADL|RADIAL|RADIEL|RADL|RAMP|RAMP|RAMP|RANCH|RANCH|RNCH|RANCHES|RNCH|RNCHS|RAPID|RAPID|RPD|RPD|RAPIDS|RAPIDS|RPDS|RPDS|REST|REST|RST|RST|RIDGE|RDG|RDG|RDGE|RIDGE|RIDGES|RDGS|RDGS|RIDGES|RIVER|RIV|RIV|RIVER|RVR|RIVR|ROAD|RD|RD|ROAD|ROADS|ROADS|RDS|RDS|ROUTE|ROUTE|RTE|ROW|ROW|ROW|RUE|RUE|RUE|RUN|RUN|RUN|SHOAL|SHL|SHL|SHOAL|SHOALS|SHLS|SHLS|SHOALS|SHORE|SHOAR|SHR|SHORE|SHR|SHORES|SHOARS|SHRS|SHORES|SHRS|SKYWAY|SKYWAY|SKWY|SPRING|SPG|SPG|SPNG|SPRING|SPRNG|SPRINGS|SPGS|SPGS|SPNGS|SPRINGS|SPRNGS|SPUR|SPUR|SPUR|SPURS|SPURS|SPUR|SQUARE|SQ|SQ|SQR|SQRE|SQU|SQUARE|SQUARES|SQRS|SQS|SQUARES|STATION|STA|STA|STATION|STATN|STN|STRAVENUE|STRA|STRA|STRAV|STRAVEN|STRAVENUE|STRAVN|STRVN|STRVNUE|STREAM|STREAM|STRM|STREME|STRM|STREET|STREET|ST|STRT|ST|STR|STREETS|STREETS|STS|SUMMIT|SMT|SMT|SUMIT|SUMITT|SUMMIT|TERRACE|TER|TER|TERR|TERRACE|THROUGHWAY|THROUGHWAY|TRWY|TRACE|TRACE|TRCE|TRACES|TRCE|TRACK|TRACK|TRAK|TRACKS|TRAK|TRK|TRKS|TRAFFICWAY|TRAFFICWAY|TRFY|TRAIL|TRAIL|TRL|TRAILS|TRL|TRLS|TRAILER|TRAILER|TRLR|TRLR|TRLRS|TUNNEL|TUNEL|TUNL|TUNL|TUNLS|TUNNEL|TUNNELS|TUNNL|TURNPIKE|TRNPK|TPKE|TURNPIKE|TURNPK|UNDERPASS|UNDERPASS|UPAS|UNION|UN|UN|UNION|UNIONS|UNIONS|UNS|VALLEY|VALLEY|VLY|VALLY|VLLY|VLY|VALLEYS|VALLEYS|VLYS|VLYS|VIADUCT|VDCT|VIA|VIA|VIADCT|VIADUCT|VIEW|VIEW|VW|VW|VIEWS|VIEWS|VWS|VWS|VILLAGE|VILL|VLG|VILLAG|VILLAGE|VILLG|VILLIAGE|VLG|VILLAGES|VILLAGES|VLGS|VLGS|VILLE|VILLE|VL|VL|VISTA|VIS|VIS|VIST|VISTA|VST|VSTA|WALK|WALK|WALK|WALKS|WALKS|WALK|WALL|WALL|WALL|WAY|WY|WAY|WAY|WAYS|WAYS|WAYS|WELL|WELL|WL|WELLS|WELLS|WLS");
			string pattern2 = string.Format("^(({0}))", "APARTMENT|APT|BUILDING|BLDG|FLOOR|FL|SUITE|STE|UNIT|UNIT|ROOM|RM|DEPARTMENT|DEPT|SPC");
			Match match = new Regex(pattern).Match(address);
			if (match.Success)
			{
				flag = true;
			}
			Match match2 = new Regex(pattern2).Match(address);
			if (match2.Success)
			{
			}
			if (flag)
			{
				result = true;
			}
			return result;
		}

		public static string HashPassword(string userName, string password)
		{
			Crypto crypto = new Crypto();
			return crypto.GetHash(System.Convert.ToString(password.Trim() + userName.Trim().ToLower()), HashAlgorithmType.SHA256);
		}

		public static string HashNewPassword(string userName, string password)
		{
			Crypto crypto = new Crypto();
			return crypto.GetHash(password.Trim() + userName.ToLower().Trim(), HashAlgorithmType.SHA256);
		}

		public static string HashAnswer(string answer)
		{
			Crypto crypto = new Crypto();
			return crypto.GetHash(answer.ToLower().Trim(), HashAlgorithmType.SHA256);
		}
	}
}
