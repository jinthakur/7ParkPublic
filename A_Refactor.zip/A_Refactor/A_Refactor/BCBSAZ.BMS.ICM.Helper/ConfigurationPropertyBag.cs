using Microsoft.BizTalk.SSOClient.Interop;
using System;
using System.Collections.Specialized;

namespace BCBSAZ.BMS.ICM.Helper
{
	public class ConfigurationPropertyBag : IPropertyBag
	{
		private HybridDictionary properties;

		internal ConfigurationPropertyBag()
		{
			this.properties = new HybridDictionary();
		}

		public void Read(string propName, out object ptrVar, int errLog)
		{
			ptrVar = this.properties[propName];
		}

		public void Write(string propName, ref object ptrVar)
		{
			this.properties.Add(propName, ptrVar);
		}

		public bool Contains(string key)
		{
			return this.properties.Contains(key);
		}

		public void Remove(string key)
		{
			this.properties.Remove(key);
		}
	}
}
