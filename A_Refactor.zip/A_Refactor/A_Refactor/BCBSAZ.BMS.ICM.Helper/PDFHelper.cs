using Aspose.Pdf;
using Aspose.Pdf.Generator;
using System;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Xml;

namespace BCBSAZ.BMS.ICM.Helper
{
	[System.Serializable]
	public class PDFHelper
	{
		private const string AppName = "BCBSAZ.BMS.ICM";

		public PDFHelper()
		{
			License license = new License();
			string license2 = SSOClientHelper.Read("BCBSAZ.BMS.ICM", "AsposeLicensePath");
			license.SetLicense(license2);
			license.Embedded = true;
		}

		protected byte[] MergeTiffFilesToPdf(System.Collections.ObjectModel.Collection<byte[]> tiffData)
		{
			return this.ConvertTiffToPdf(tiffData);
		}

		protected byte[] MergeHtmlFilesToPdf(System.Collections.ObjectModel.Collection<byte[]> tiffData)
		{
			return this.ConvertHtmlToPdf(tiffData);
		}

        private byte[] ConvertTiffToPdf(Collection<byte[]> docBytes)
        {
            byte[] output;
            using (var documentStream = new MemoryStream())
            {
                var document = new Aspose.Pdf.Document();
                Aspose.Pdf.License license = new Aspose.Pdf.License();
                string path = SSOClientHelper.Read(AppName, "AsposeLicensePath");
                license.SetLicense(path);
                license.Embedded = true;

                document.OptimizeResources(new Aspose.Pdf.Document.OptimizationOptions
                {
                    CompressImages = true,
                });

                foreach (var pageBytes in docBytes)
                {
                    var page = document.Pages.Add();
                    page.PageInfo.Margin.Bottom = 0;
                    page.PageInfo.Margin.Left = 0;
                    page.PageInfo.Margin.Right = 0;
                    page.PageInfo.Margin.Top = 0;


                    var image = new Aspose.Pdf.Image
                    {
                        ImageStream = new MemoryStream(pageBytes),
                        IsBlackWhite = true,
                    };
                    page.Paragraphs.Add(image);
                    page.FreeMemory();
                }
                document.Save(documentStream);
                document.FreeMemory();
                output = documentStream.ToArray();
            }
            return output;
        }

        private byte[] ConvertHtmlToPdf(Collection<byte[]> docBytes)
        {

            byte[] output;
            // Instantiate an object PDF class
            Aspose.Pdf.Generator.Pdf pdf = new Aspose.Pdf.Generator.Pdf();
            Aspose.Pdf.License license = new Aspose.Pdf.License();
            string path = SSOClientHelper.Read(AppName, "AsposeLicensePath");
            license.SetLicense(path);
            license.Embedded = true;
            using (var documentStream = new MemoryStream())
            {

                foreach (var pageBytes in docBytes)
                {
                    // add the section to PDF document sections collection
                    Aspose.Pdf.Generator.Section section = pdf.Sections.Add();
                    var stream = new MemoryStream(pageBytes);
                    var streamReader = new StreamReader(stream);

                    //Create text paragraphs containing HTML text
                    Aspose.Pdf.Generator.Text text2 = new Aspose.Pdf.Generator.Text(section, streamReader.ReadToEnd());
                    // enable the property to display HTML contents within their own formatting
                    text2.IsHtmlTagSupported = true;
                    //Add the text paragraphs containing HTML text to the section
                    section.Paragraphs.Add(text2);


                }
                pdf.Save(documentStream);

                output = documentStream.ToArray();
            }
            return output;
        }

        public string converttopdf(XmlDocument xmlDoc, string contentFormat, string xPath, string SourceSystem)
		{
			System.Collections.ObjectModel.Collection<byte[]> collection = new System.Collections.ObjectModel.Collection<byte[]>();
			XmlNodeList xmlNodeList = xmlDoc.SelectNodes(xPath);
			string result;
			try
			{
				foreach (XmlNode xmlNode in xmlNodeList)
				{
					string s = string.Empty;
					if (SourceSystem == "Pinnacle")
					{
						s = xmlNode["PageData"].InnerText;
					}
					else if (SourceSystem == "Clipboard")
					{
						s = xmlNode["Page"].InnerText;
					}
					else if (SourceSystem == "Dropfax")
					{
						s = xmlNode["Page"].InnerText;
					}
					else
					{
						s = xmlNode["PageData"].InnerText;
					}
					byte[] item = System.Convert.FromBase64String(s);
					collection.Add(item);
				}
				byte[] source;
				if (contentFormat == "Html")
				{
					source = this.MergeHtmlFilesToPdf(collection);
				}
				else
				{
					source = this.MergeTiffFilesToPdf(collection);
				}
				result = System.Convert.ToBase64String(source.ToArray<byte>());
			}
			catch (System.Exception)
			{
				throw;
			}
			return result;
		}

		protected byte[] MergeTiffFilesToPdf2(System.Collections.ObjectModel.Collection<byte[]> tiffData)
		{
			return this.ConvertTiffToPdf2(tiffData);
		}

        private byte[] ConvertTiffToPdf2(Collection<byte[]> docBytes)
        {
            byte[] output;
            // Now, first convert byte arrays into MemoryStreams and then concatenate those streams
            using (var documentStream = new MemoryStream())
            {
                var document = new Aspose.Pdf.Document();
                var pdf = new Aspose.Pdf.Generator.Pdf();
                Aspose.Pdf.License license = new Aspose.Pdf.License();
                string path = SSOClientHelper.Read(AppName, "AsposeLicensePath");
                license.SetLicense(path);
                license.Embedded = true;
                //PdfFileEditor pdfEditor = new PdfFileEditor();
                //pdfEditor.Concatenate(new string[]{docBytes}, documentStream);
                int index = 0;
                foreach (var pageBytes in docBytes)
                {
                    index = index + 1;
                    MemoryStream mystream = new MemoryStream(pageBytes);
                    //FileStream test = new FileStream(mystream);
                    //// Create instance of PdfFileEditor class to concatenate streams
                    //PdfFileEditor pdfEditor = new PdfFileEditor();
                    //// Concatenate both input MemoryStreams and save to putput MemoryStream
                    ////pdfEditor.Concatenate(fileStream1, fileStream2, pdfStream);
                    //pdfEditor.Concatenate(mystream, documentStream);
                    //var page = document.Pages.Add();
                    //page.PageInfo.Margin.Bottom = 0;
                    //page.PageInfo.Margin.Left = 0;
                    //page.PageInfo.Margin.Right = 0;
                    //page.PageInfo.Margin.Top = 0;


                    //var image = new Aspose.Pdf.Image
                    //{
                    //    ImageStream = new MemoryStream(pageBytes),
                    //    IsBlackWhite = true,
                    //};
                    //page.Paragraphs.Add(image);
                    //page.FreeMemory();
                    Aspose.Pdf.Document inputDoc = new Document(mystream);



                    document.Pages.Insert(index, inputDoc.Pages);



                }
                document.Save(documentStream);

                output = documentStream.ToArray();
            }
            return output;
        }
    }
}
