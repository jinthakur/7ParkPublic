using Newtonsoft.Json;
using System;
using System.Xml;

namespace BCBSAZ.BMS.ICM.Helper
{
	[System.Serializable]
	public class JsonHelper
	{
		public static XmlDocument ConvertJsonToXml(string json, string rootnodename)
		{
			XmlDocument xmlDocument = new XmlDocument();
			return JsonConvert.DeserializeXmlNode(json, rootnodename);
		}

		public static string ConvertXmlToJson(XmlDocument xml)
		{
			string empty = string.Empty;
			return JsonConvert.SerializeXmlNode(xml, 0, true);
		}
	}
}
