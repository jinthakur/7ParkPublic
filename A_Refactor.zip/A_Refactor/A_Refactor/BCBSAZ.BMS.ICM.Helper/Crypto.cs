using System;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;

namespace BCBSAZ.BMS.ICM.Helper
{
	[System.Serializable]
	public class Crypto
	{
		[System.Runtime.InteropServices.ComVisible(true)]
		public string GetHash(string strInput, HashAlgorithmType hshType)
		{
			System.Text.UnicodeEncoding unicodeEncoding = new System.Text.UnicodeEncoding();
			string text = "";
			if (strInput.Length > 0)
			{
				byte[] bytes = unicodeEncoding.GetBytes(strInput);
				byte[] array = bytes;
				switch (hshType)
				{
				case HashAlgorithmType.MD5:
				{
					System.Security.Cryptography.MD5 mD = new System.Security.Cryptography.MD5CryptoServiceProvider();
					array = mD.ComputeHash(bytes);
					break;
				}
				case HashAlgorithmType.SHA1:
				{
					System.Security.Cryptography.SHA1Managed sHA1Managed = new System.Security.Cryptography.SHA1Managed();
					array = sHA1Managed.ComputeHash(bytes);
					break;
				}
				case HashAlgorithmType.SHA256:
				{
					System.Security.Cryptography.SHA256Managed sHA256Managed = new System.Security.Cryptography.SHA256Managed();
					array = sHA256Managed.ComputeHash(bytes);
					break;
				}
				case HashAlgorithmType.SHA384:
				{
					System.Security.Cryptography.SHA384Managed sHA384Managed = new System.Security.Cryptography.SHA384Managed();
					array = sHA384Managed.ComputeHash(bytes);
					break;
				}
				case HashAlgorithmType.SHA512:
				{
					System.Security.Cryptography.SHA512Managed sHA512Managed = new System.Security.Cryptography.SHA512Managed();
					array = sHA512Managed.ComputeHash(bytes);
					break;
				}
				}
				byte[] array2 = array;
				for (int i = 0; i < array2.Length; i++)
				{
					byte b = array2[i];
					text += string.Format("{0:x2}", b);
				}
			}
			else
			{
				text = "";
			}
			return text;
		}
	}
}
