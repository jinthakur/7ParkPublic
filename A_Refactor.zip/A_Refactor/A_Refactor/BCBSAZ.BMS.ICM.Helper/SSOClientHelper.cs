using Microsoft.BizTalk.SSOClient.Interop;
using System;
using System.Diagnostics;

namespace BCBSAZ.BMS.ICM.Helper
{
	public class SSOClientHelper
	{
		private static string idenifierGUID = "ConfigProperties";

		public static string Read(string appName, string propName)
		{
			string result;
			try
			{
				SSOConfigStore sSOConfigStore = new SSOConfigStore();
				ConfigurationPropertyBag configurationPropertyBag = new ConfigurationPropertyBag();
				((ISSOConfigStore)sSOConfigStore).GetConfigInfo(appName, SSOClientHelper.idenifierGUID, 4, configurationPropertyBag);
				object obj = null;
				configurationPropertyBag.Read(propName, out obj, 0);
				if (string.IsNullOrEmpty((string)obj) || ((string)obj).Equals("EMPTY"))
				{
					result = "";
				}
				else
				{
					result = (string)obj;
				}
			}
			catch (System.Exception ex)
			{
				Trace.WriteLine(ex.Message);
				throw;
			}
			return result;
		}

		public static string ReadFromSSOStore(string appName, string propName)
		{
			string result;
			try
			{
				SSOConfigStore sSOConfigStore = new SSOConfigStore();
				ConfigurationPropertyBag configurationPropertyBag = new ConfigurationPropertyBag();
				((ISSOConfigStore)sSOConfigStore).GetConfigInfo(appName, SSOClientHelper.idenifierGUID, 4, configurationPropertyBag);
				object obj = null;
				configurationPropertyBag.Read(propName, out obj, 0);
				result = (string)obj;
			}
			catch (System.Exception ex)
			{
				Trace.WriteLine(ex.Message);
				throw;
			}
			return result;
		}
	}
}
