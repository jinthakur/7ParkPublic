using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Net.Security;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

namespace BCBSAZ.BMS.ICM.Helper
{
	[System.Serializable]
	public class RestHelper
	{
		private static System.DateTime _sessionLastAccessDate = System.DateTime.Now;

		private static string _sessionId = string.Empty;

		private static string _applicationName = "BCBSAZ.BMS.ICM";

		public static string GetSessionID(string username, string password, string serviceUrl)
		{
			string message = string.Format("Starting GetSessionID: _sessionLastAccessDate: {0}, _sessionId: {1}, _applicationName:{2} ", RestHelper._sessionLastAccessDate, RestHelper._sessionId, RestHelper._applicationName);
			Debug.Write(message);
			System.TimeSpan timeSpan = System.DateTime.Now.Subtract(RestHelper._sessionLastAccessDate);
			int num = System.Convert.ToInt32(SSOClientHelper.Read(RestHelper._applicationName, "CacheInterval"));
			try
			{
				ServicePointManager.SecurityProtocol = SecurityProtocolType.Ssl3 | SecurityProtocolType.Tls | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls12;
				HttpClient httpClient = new HttpClient();
				ServicePointManager.ServerCertificateValidationCallback = (RemoteCertificateValidationCallback)System.Delegate.Combine(ServicePointManager.ServerCertificateValidationCallback, new RemoteCertificateValidationCallback((object sender, System.Security.Cryptography.X509Certificates.X509Certificate certificate, X509Chain chain, SslPolicyErrors sslPolicyErrors) => true));
				HttpContent httpContent = new FormUrlEncodedContent(new System.Collections.Generic.Dictionary<string, string>
				{
					{
						"u",
						username
					},
					{
						"p",
						password
					}
				});
				Debug.Write("Get Session ID: ", "Send Request to ICM");
				Task<HttpResponseMessage> task = httpClient.PostAsync(serviceUrl, httpContent);
				Debug.Write("Get Session ID: ", "Received Response from ICM");
				Debug.Write("Get Session ID Response: ", task.ToString());
				if (task.Result != null)
				{
					Debug.Write("Get Session ID Response: ", task.Result.IsSuccessStatusCode.ToString());
				}
				if (task.Result.IsSuccessStatusCode)
				{
					HttpContent content = task.Result.Content;
					XmlDocument xmlDocument = new XmlDocument();
					xmlDocument.LoadXml(content.ReadAsStringAsync().Result);
					RestHelper._sessionId = xmlDocument.SelectSingleNode("//cald-sessionid").InnerText;
					Debug.Write("GetSession: ", "New SessionID acquired");
					Debug.Write("_sessionId: " + RestHelper._sessionId);
				}
			}
			catch (System.Exception ex)
			{
				Debug.Write("GetSession: ", ex.Message);
				RestHelper._sessionId = ex.Message;
				throw ex;
			}
			RestHelper._sessionLastAccessDate = System.DateTime.Now;
			message = string.Format("End of GetSessionID: _sessionLastAccessDate: {0}, _sessionId: {1}, _applicationName:{2} ", RestHelper._sessionLastAccessDate, RestHelper._sessionId, RestHelper._applicationName);
			Debug.Write(message);
			return RestHelper._sessionId;
		}

		public XmlDocument QueryCallidus(string sessionId, string QueryString, string serviceUrl)
		{
			XmlDocument xmlDocument = new XmlDocument();
			string text = string.Empty;
			try
			{
				ServicePointManager.SecurityProtocol = (SecurityProtocolType.Ssl3 | SecurityProtocolType.Tls | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls12);
				int num = System.Convert.ToInt32(SSOClientHelper.Read(RestHelper._applicationName, "ApiWaitTime"));
				HttpClient httpClient = new HttpClient();
				httpClient.Timeout = (System.TimeSpan.FromMilliseconds((double)num));
				string text2 = serviceUrl + QueryString;
				HttpRequestMessage httpRequestMessage = new HttpRequestMessage(HttpMethod.Get, text2);
				httpRequestMessage.Headers.Add("CaldSessionId", sessionId);
				httpRequestMessage.Headers.Accept.Add(new MediaTypeWithQualityHeaderValue("application/xml"));
				Debug.Write("QueryCallidus: ", "Send Request From  Callidus");
				Task<HttpResponseMessage> task = httpClient.SendAsync(httpRequestMessage);
				Debug.Write("QueryCallidus: ", "Received Response From  Callidus");
				HttpContent content = task.Result.Content;
				text = content.ReadAsStringAsync().Result;
				Debug.Write("Response from Calidus in str (logic got past extraction of contents) :" + text);
				xmlDocument.LoadXml(text);
			}
			catch (System.Exception ex)
			{
				Debug.Write(ex);
				throw ex;
			}
			return xmlDocument;
		}

		public XmlDocument PostRequestToCallidus(string sessionId, XmlDocument postXML, string serviceUrl)
		{
			XmlDocument xmlDocument = new XmlDocument();
			try
			{
				ServicePointManager.SecurityProtocol = (SecurityProtocolType.Ssl3 | SecurityProtocolType.Tls | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls12);
				HttpClient httpClient = new HttpClient();
				HttpContent content = new StringContent(postXML.OuterXml.ToString(), System.Text.Encoding.UTF8, "application/xml");
				HttpRequestMessage httpRequestMessage = new HttpRequestMessage(HttpMethod.Post, serviceUrl);
				httpRequestMessage.Headers.Add("CaldSessionId", sessionId);
				httpRequestMessage.Headers.Accept.Add(new MediaTypeWithQualityHeaderValue("application/xml"));
				httpRequestMessage.Content = content;
				Debug.Write("POSTRequest To Callidus: ", "Send Request From  Callidus");
				Task<HttpResponseMessage> task = httpClient.SendAsync(httpRequestMessage);
				Debug.Write("POSTRequest To Callidus: ", "Received Response From  Callidus");
				HttpContent content2 = task.Result.Content;
				string result = content2.ReadAsStringAsync().Result;
				Debug.Write("Response from Calidus in str (logic got past extraction of contents) :" + result);
				xmlDocument.LoadXml(result);
			}
			catch (System.Exception ex)
			{
				Debug.Write(ex);
				throw ex;
			}
			return xmlDocument;
		}

		public string PostRequestToWFCallidus(string authToken, string json, string serviceUrl)
		{
			string text = string.Empty;
			string text2 = "Basic " + authToken;
			try
			{
                Debug.Write("Calling Logic Apps -- authToken", authToken);
                Debug.Write("Calling Logic Apps -- Json", json);
                Debug.Write("Calling Logic Apps -- serviceUrl", serviceUrl);
                //serviceUrl = "https://logicaisclaims837d002.azurewebsites.net:443/api/TestBrokerCall/triggers/When_a_HTTP_request_is_received/invoke?api-version=2022-05-01&sp=%2Ftriggers%2FWhen_a_HTTP_request_is_received%2Frun&sv=1.0&sig=JfnGc1fPSEhlFSPR7HbhN4SZGHEuawY56Xzjxb6iifw";
                Debug.Write("Finished calling Logic Apps", authToken);
                ServicePointManager.SecurityProtocol = (SecurityProtocolType.Ssl3 | SecurityProtocolType.Tls | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls12);
				HttpClient httpClient = new HttpClient();
				ServicePointManager.ServerCertificateValidationCallback = (RemoteCertificateValidationCallback)System.Delegate.Combine(ServicePointManager.ServerCertificateValidationCallback, new RemoteCertificateValidationCallback((object sender, System.Security.Cryptography.X509Certificates.X509Certificate certificate, X509Chain chain, SslPolicyErrors sslPolicyErrors) => true));
				HttpContent content = new StringContent(json, System.Text.Encoding.UTF8, "application/json");
				httpClient.DefaultRequestHeaders.Add("User-Agent", "Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2228.0 Safari/537.36");
				HttpRequestMessage httpRequestMessage = new HttpRequestMessage(HttpMethod.Post, serviceUrl);
				httpRequestMessage.Headers.Add("Authorization", text2);
				httpRequestMessage.Headers.Add("domain", "bcbs_arizona");
				httpRequestMessage.Headers.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
				httpRequestMessage.Content = content;
				Debug.Write("POSTRequest To Callidus: ", "Send Request From  Callidus");
				Task<HttpResponseMessage> task = httpClient.SendAsync(httpRequestMessage);
				Debug.Write("POSTRequest To Callidus: ", "Received Response From  Callidus");
				HttpContent content2 = task.Result.Content;
				string result = content2.ReadAsStringAsync().Result;
				text = result;
				Debug.Write("Response from LogicApps in str (logic got past extraction of contents) :" + text);
			}
			catch (System.Exception ex)
			{
                Debug.Write("Exception new code", ex.Message);
                Debug.Write(ex);
				throw ex;
			}
			return text;
		}

		public string PostAttachmentToCallidus(string authToken, string pdfBase64string, string serviceUrl)
		{
			string text = string.Empty;
			string text2 = "\"" + pdfBase64string + "\"";
			string text3 = "Basic " + authToken;
			try
			{
				ServicePointManager.SecurityProtocol = (SecurityProtocolType.Ssl3 | SecurityProtocolType.Tls | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls12);
				HttpClient httpClient = new HttpClient();
				HttpContent content = new StringContent(text2, System.Text.Encoding.UTF8, "application/json");
				HttpRequestMessage httpRequestMessage = new HttpRequestMessage(HttpMethod.Post, serviceUrl);
				httpRequestMessage.Headers.Add("Authorization", text3);
				httpRequestMessage.Headers.Add("domain", "bcbs_arizona");
				httpRequestMessage.Headers.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
				httpRequestMessage.Content = content;
				Debug.Write("POSTRequest To Callidus: ", "Send Request From  Callidus");
				Task<HttpResponseMessage> task = httpClient.SendAsync(httpRequestMessage);
				Debug.Write("POSTRequest To Callidus: ", "Received Response From  Callidus");
				HttpContent content2 = task.Result.Content;
				string result = content2.ReadAsStringAsync().Result;
				text = result;
				Debug.Write("Response from Calidus in str (logic got past extraction of contents) :" + text);
			}
			catch (System.Exception ex)
			{
				Debug.Write(ex);
				throw ex;
			}
			return text;
		}

		public string PutRequestToWFCallidus(string authToken, string json, string serviceUrl)
		{
			string text = string.Empty;
			string text2 = "Basic " + authToken;
			try
			{
				ServicePointManager.SecurityProtocol = (SecurityProtocolType.Ssl3 | SecurityProtocolType.Tls | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls12);
				HttpClient httpClient = new HttpClient();
				ServicePointManager.ServerCertificateValidationCallback = (RemoteCertificateValidationCallback)System.Delegate.Combine(ServicePointManager.ServerCertificateValidationCallback, new RemoteCertificateValidationCallback((object sender, System.Security.Cryptography.X509Certificates.X509Certificate certificate, X509Chain chain, SslPolicyErrors sslPolicyErrors) => true));
				HttpContent content = new StringContent(json, System.Text.Encoding.UTF8, "application/json");
				HttpRequestMessage httpRequestMessage = new HttpRequestMessage(HttpMethod.Put, serviceUrl);
				httpRequestMessage.Headers.Add("Authorization", text2);
				httpRequestMessage.Headers.Add("domain", "bcbs_arizona");
				httpRequestMessage.Headers.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
				httpRequestMessage.Content = content;
				Debug.Write("POSTRequest To Callidus: ", "Send Request From  Callidus");
				Task<HttpResponseMessage> task = httpClient.SendAsync(httpRequestMessage);
				Debug.Write("POSTRequest To Callidus: ", "Received Response From  Callidus");
				if (task != null)
				{
					Debug.Write("Response from Calidus" + task.ToString());
				}
				else
				{
					Debug.Write("Response from Calidus is null");
				}
				HttpContent content2 = task.Result.Content;
				string result = content2.ReadAsStringAsync().Result;
				text = result;
				Debug.Write("Response from Calidus in str (logic got past extraction of contents) :" + text);
			}
			catch (System.Exception ex)
			{
				Debug.Write(ex);
				throw ex;
			}
			return text;
		}

		public string PostAttachmentToCallidus2(string authToken, string attachmentUrl, string casePath, string fileName)
		{
			string text = string.Empty;
			string path = casePath + "\\" + fileName;
			try
			{
				ServicePointManager.SecurityProtocol = (SecurityProtocolType.Ssl3 | SecurityProtocolType.Tls | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls12);
				string str = string.Format("----------{0:N}", System.Guid.NewGuid());
				string text2 = "multipart/form-data; boundary=" + str;
				HttpClient httpClient = new HttpClient();
				ServicePointManager.ServerCertificateValidationCallback = (RemoteCertificateValidationCallback)System.Delegate.Combine(ServicePointManager.ServerCertificateValidationCallback, new RemoteCertificateValidationCallback((object sender, System.Security.Cryptography.X509Certificates.X509Certificate certificate, X509Chain chain, SslPolicyErrors sslPolicyErrors) => true));
                httpClient.DefaultRequestHeaders.Add("X-Atlassian-Token", "nocheck");
                httpClient.DefaultRequestHeaders.Add("domain", "bcbs_arizona");
                httpClient.DefaultRequestHeaders.Add("ContectType", text2);
                httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Basic", authToken);
				MultipartFormDataContent multipartFormDataContent = new MultipartFormDataContent();
				multipartFormDataContent.Add(new StreamContent(System.IO.File.Open(path, System.IO.FileMode.Open)), "uploaded_file", fileName);
				Task<HttpResponseMessage> task = httpClient.PostAsync(attachmentUrl, multipartFormDataContent);
				Debug.Write("POSTAttachement To Callidus: ", "Received Response From  Callidus");
				HttpContent content = task.Result.Content;
				string result = content.ReadAsStringAsync().Result;
				text = result;
				Debug.Write("Response from Calidus in str (logic got past extraction of contents) :" + text);
			}
			catch (System.Exception ex)
			{
				Debug.Write(ex);
				throw ex;
			}
			return text;
		}
	}
}
