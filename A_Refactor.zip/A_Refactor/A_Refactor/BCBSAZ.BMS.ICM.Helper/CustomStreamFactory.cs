using Microsoft.XLANGs.BaseTypes;
using System;
using System.IO;

namespace BCBSAZ.BMS.ICM.Helper
{
	[System.Serializable]
	public class CustomStreamFactory : IStreamFactory
	{
		private byte[] _data;

		public CustomStreamFactory(byte[] b)
		{
			this._data = b;
		}

		public System.IO.Stream CreateStream()
		{
			return new System.IO.MemoryStream(this._data);
		}
	}
}
